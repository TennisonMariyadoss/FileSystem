package com.fileSystem.dao;

import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fileSystem.common.Constants;
import com.fileSystem.common.DataSheet;
import com.fileSystem.service.FileException;
import com.fileSystem.service.FileSystemValidation;
import com.fileSystem.service.LoadProperties;

public class FileSysteDaoImpl implements FileSystemDao {

	private JSONObject dataSheet;

	private File file;

	private FileReader reader;

	private FileWriter writer;

	private JSONParser jsonParser;

	private ObjectMapper mapper;

	private Long timeToLive;

	private FileSystemValidation validation = FileSystemValidation.getFileSystemValidationInstance();

	private LoadProperties properties = LoadProperties.getLoadProperties();

	public FileSysteDaoImpl() throws FileException {
		try {
			jsonParser = new JSONParser();
			mapper = new ObjectMapper();
			properties.setLoadProperties(Constants.FILE_SYS);
			timeToLive = Long.parseLong(properties.getFileProperties("timeToLive"));
			loadDateSheet();
		} catch (IOException e) {
			throw new FileException("101");
		}
	}

	void loadDateSheet() throws FileException {
		try {
			String filePath = properties.getFileProperties("filePath");

			file = filePath != null ? new File(filePath) : new File("dataSheet.json");
			if (file.exists()) {
				reader = new FileReader(file);
			} else {
				file.createNewFile();
				reader = new FileReader(file);
			}
			if ((reader.read()) != -1) {
				dataSheet = (JSONObject) jsonParser.parse(reader);
			} else {
				dataSheet = new JSONObject();
			}

		} catch (IOException e) {
			throw new FileException("104");
		} catch (ParseException e) {
			throw new FileException("102");
		}

	}

	public JSONObject getDataSheet() {
		return dataSheet;
	}

	@SuppressWarnings("unchecked")
	public synchronized String create(String key, DataSheet value) throws FileException {

		if (validation.checkSpace(file.length())) {
			try {
				writer = new FileWriter(file);
				value.setTime(new Date().getTime());
				JSONObject obj = new JSONObject();
				obj.put("value", value.getValue());
				obj.put("time", value.getTime());
				dataSheet.put(key,obj);
				writer.write(dataSheet.toJSONString());
				writer.flush();
			} catch (IOException e) {
				throw new FileException("105");
			}

		} else {
			throw new FileException("103");
		}
		return properties.getFileProperties("create.success.msg");
	}

	public String delete(String key) throws FileException {

		try {
			reader = new FileReader(file);
			dataSheet = (JSONObject) jsonParser.parse(reader);
			JSONObject jsonValue = (JSONObject) dataSheet.get(key);
			if (jsonValue == null || jsonValue.toJSONString().isEmpty()) {
				throw new FileException("107");
			} else {
				DataSheet value = mapper.readValue(jsonValue.toJSONString(), DataSheet.class);
				if (validation.validateRead(value.getTime(), timeToLive)) {
					synchronized (file) {
						dataSheet.remove(key);
						writer = new FileWriter(file);
						writer.write(dataSheet.toJSONString());
						writer.flush();
					}

				} else {
					throw new FileException("106");
				}
			}
		} catch (IOException e) {
			throw new FileException("104");
		} catch (ParseException e) {
			throw new FileException("102");
		}
		return properties.getFileProperties("delete.success.msg");
	}

	public DataSheet read(String key) throws FileException {
		try {
			reader = new FileReader(file);
			dataSheet = (JSONObject) jsonParser.parse(reader);
			JSONObject jsonValue = (JSONObject) dataSheet.get(key);
			if (jsonValue == null || jsonValue.toJSONString().isEmpty()) {
				throw new FileException("107");
			} else {
				DataSheet value = mapper.readValue(jsonValue.toJSONString(), DataSheet.class);
				if (validation.validateRead(value.getTime(), timeToLive)) {
					return value;
				} else {
					throw new FileException("106");
				}
			}
		} catch (IOException e) {
			throw new FileException("104");
		} catch (ParseException e) {
			throw new FileException("102");
		}
	}

}
